const express = require("express")
const path= require("path");
const fs = require("fs");
const app = express();
const bodyParser = require("body-parser");
app.set('view engine','ejs')
app.engine('html', require('ejs').renderFile);

app.set('views',path.join(__dirname,'views'))
app.use(bodyParser.urlencoded({ extended: true }))

// fs.writeFileSync('database.txt');

app.get('/data', (req, res) => {

    res.render('data.html');
});

app.get("/",(req,res)=>{
    // res.send("Hlolo world");
    res.render('home.html');
    
});

app.post("/",(req,res)=>{
    res.status(200).render('home.html');
    console.log(req.body.email);
    one=req.body.fname;
    email=req.body.email;
    bookname=req.body.bookname;
    quantity=req.body.quantity;
    address=req.body.address;
    number=req.body.number;
    let outputtowrite = `${one} : ${email} : ${address} : ${number} : ${bookname} : ${quantity}\n`
    fs.appendFileSync("database.txt",outputtowrite)
    console.log("hello");
});

app.listen(800,()=>{
    console.log("Application starterd on " );
})